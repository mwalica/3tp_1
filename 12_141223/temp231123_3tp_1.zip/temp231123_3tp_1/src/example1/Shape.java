package example1;

import javax.swing.text.View;

public abstract class Shape implements Clickable{
    protected String name;

    public Shape(String name) {
        this.name = name;
    }


    public void info() {
        System.out.println("Jestem " + name);
    }

    public String getName() {
        return name;
    }

    abstract double area();

    @Override
    public String gotTo() {
        return "Przejeście do innego kształtu";
    }
}
