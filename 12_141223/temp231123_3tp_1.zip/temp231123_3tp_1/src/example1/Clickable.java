package example1;

public interface Clickable {

    public String gotTo();
    public String exit();
}
