package example1;

public class Main {
    public static void main(String[] args) {

//        Shape shape1 = new Shape("nieznany kształt");
        Rectangle rectangle1 = new Rectangle(2, 5);
        Rectangle rectangle2 = new Rectangle(5);
        Rectangle rectangle3 = new Rectangle(2, 6, "prostokącik");
        Circle circle1 = new Circle(3);

//        shape1.info();
        rectangle1.info();
        rectangle2.info();
        rectangle3.info();
        circle1.info();
        System.out.println(circle1.area());
        System.out.println(rectangle1.area());

    }
}
