package example1;

public class Button implements Clickable{
    private String text;
    private String bgColor;

    public Button(String text, String bgColor) {
        this.text = text;
        this.bgColor = bgColor;
    }


    @Override
    public String gotTo() {
        return null;
    }

    @Override
    public String exit() {
        return null;
    }
}
