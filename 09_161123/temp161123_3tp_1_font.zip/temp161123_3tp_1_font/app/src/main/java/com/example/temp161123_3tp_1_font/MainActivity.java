package com.example.temp161123_3tp_1_font;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etText;
    private Button btnSend;
    private TextView tvResul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etText = findViewById(R.id.etText);
        btnSend = findViewById(R.id.btnSend);
        tvResul = findViewById(R.id.tvResult);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = etText.getText().toString().trim();
                if(!text.isEmpty()) {
                    tvResul.setText(text);
                } else {
                    Toast.makeText(MainActivity.this, "Proszę wypełnić pole tekstowe", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}