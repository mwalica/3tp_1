package com.example.temp21123_3tp_1_toast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button btnShowToast, btnHideToast;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnShowToast = findViewById(R.id.btnShowToast);
        btnHideToast = findViewById(R.id.btnHideToast);


        Toast toast = Toast.makeText(MainActivity.this, getString(R.string.toast_msg), Toast.LENGTH_LONG);

        btnShowToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //kontekst, treść, długość trwania
                toast.show();
            }
        });

        btnHideToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toast.cancel();
            }
        });
    }
}