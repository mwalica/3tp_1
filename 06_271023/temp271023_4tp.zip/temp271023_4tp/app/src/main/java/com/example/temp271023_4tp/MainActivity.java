package com.example.temp271023_4tp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult1, tvResult2;
    private Button btnShowHide1, btnShowHide2, btnShowHide3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult1 = findViewById(R.id.tvResult1);
        tvResult2 = findViewById(R.id.tvResult2);
        btnShowHide1 = findViewById(R.id.btnShowHide1);
        btnShowHide2 = findViewById(R.id.btnShowHide2);
        btnShowHide3 = findViewById(R.id.btnShowHide3);

        btnShowHide1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvResult1.getText().equals("")) {
                    tvResult1.setText("Jestem pierwszym tekstem");
                    btnShowHide1.setText("Ukryj");
                } else {
                    tvResult1.setText("");
                    btnShowHide1.setText("Pokaż");
                }

            }
        });

        btnShowHide2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvResult2.getText().equals("")) {
                    tvResult2.setText("Jestem drugim tekstem");
                    btnShowHide2.setText("Ukryj");
                } else {
                    tvResult2.setText("");
                    btnShowHide2.setText("Pokaż");
                }

            }
        });

        btnShowHide3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvResult2.getVisibility() == View.GONE) {
                    tvResult2.setVisibility(View.VISIBLE);
                    btnShowHide3.setText("Ukryj");
                } else {
                    tvResult2.setVisibility(View.GONE);
                    btnShowHide3.setText("Pokaż");
                }
            }
        });


    }
}