package lesson280923;

public class Example6 {
    public static void main(String[] args) {
        String name = "Karol";
        StringBuilder name2 = new StringBuilder("Karol");
        name2.append(" jest ok");
        System.out.println(name2);

//        String str1 = "";
//        for(int i = 0; i < 100000; i++) {
//            str1 += " " + i;
//        }
//        System.out.println(str1);

        StringBuilder str1 = new StringBuilder("");
        for(int i = 0; i < 1000000; i++) {
            str1.append(" " + i);
        }
        System.out.println(str1);
    }
}
