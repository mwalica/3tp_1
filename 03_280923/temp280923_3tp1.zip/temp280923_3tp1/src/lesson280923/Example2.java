package lesson280923;

public class Example2 {
    public static void main(String[] args) {
        double doubleNum = 3.4567534534;
        float floatNum = 3434.4567f;
        long longNum = 2346;
        int intNum = 246;
        short shortNum = 130;
        byte byteNum = 13;
        char letter = 'e';

        double result1 = doubleNum + floatNum;
        float result2 = intNum + floatNum;
        int result3 = byteNum + shortNum;
        int result4 = shortNum + letter;
        char result5 = (char) (shortNum + letter);
        int a = 10;
        int b = 20;
        double result6 =(double) a / b;
        System.out.println(result6);
    }
}
