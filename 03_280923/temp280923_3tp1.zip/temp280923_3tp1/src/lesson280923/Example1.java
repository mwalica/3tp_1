package lesson280923;

public class Example1 {
    public static void main(String[] args) {
        double doubleNum = 3.4567534534;
        float floatNum = 3434.4567f;
        long longNum = 2346;
        int intNum = 246;
        short shortNum = 130;
        byte byteNum = 13;

        //mniejszy do większego konwersja typów
        //byte short int long float double
        int num1 = shortNum;
        double num2 = longNum;
        System.out.println(num1);
        System.out.println(num2);
        //wiekszy do mniejszego konwersja typów
        //czasami jest utrata informacji
        float num3 = (float) doubleNum;
        System.out.println(doubleNum + " " + num3);
        byte num4 = (byte) shortNum;//utrata danych
        System.out.println(shortNum + " " + num4);
        int num5 = (int) doubleNum;
        System.out.println(doubleNum + " " + num5);

    }
}
