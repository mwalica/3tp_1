package lesson280923;

public class Example5 {
    public static void main(String[] args) {
        int age = 23;
        String name = "Jan";

        String str1 = name + " ma lat " + age + ".";
        String str2 = "" + age + 34 + " " + name + (age + 45);
        System.out.println(str1);
        System.out.println(str2);
        String str3 = name.concat(" ma lat ").concat(String.valueOf(age));
        System.out.println(str3);


    }
}
