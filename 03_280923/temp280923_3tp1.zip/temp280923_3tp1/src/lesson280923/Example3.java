package lesson280923;

public class Example3 {

    public static void main(String[] args) {
        int a = 23;
        {
            int b = 34;
            a = 45;
            System.out.println("inner a = " + a);
            System.out.println("inner b = " + b);
        }
        System.out.println("outer a = " + a);
//        System.out.println("outer b = " + b);
    }

    public void func2() {
        int a = 45;
        System.out.println("a = " + a);
    }
}
