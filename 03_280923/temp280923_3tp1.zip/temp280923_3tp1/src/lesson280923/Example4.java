package lesson280923;

public class Example4 {

    char letter;
    public static void main(String[] args) {
        int a = 45;
        int b = 45;
        String emptyStr = "";
        String car1 = "Fiat";
        String car2 = new String("Ford");
        String car3 = null;
        car3 = car1;
        car2 = null;

        //porównywanie typów prosty i klasowych

        System.out.println("a = b: " + (a == b));
        String name1 = "Jan";
        String name2 = "Jan";
        String name3 = new String("Jan");
        String name4 = name3;
        String name5 = "JAN";

        System.out.println(name1 == name2);
        System.out.println(name1 == name3);
        System.out.println(name1 == name4);
        System.out.println(name3 == name4);

        System.out.println(name1.equals(name2));
        System.out.println(name1.equals(name3));
        System.out.println(name1.equals(name4));
        System.out.println(name3.equalsIgnoreCase(name4));
        System.out.println(name1.equalsIgnoreCase(name5));


    }
}
