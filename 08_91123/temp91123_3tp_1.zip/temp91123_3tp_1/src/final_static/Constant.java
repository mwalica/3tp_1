package final_static;public class Constant {
}
