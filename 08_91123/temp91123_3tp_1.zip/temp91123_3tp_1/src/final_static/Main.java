package final_static;

public class Main {
    public static void main(String[] args) {

        System.out.println(Car.numberCar);

        System.out.println(Car.SERIAL_NUMBER_CAR);
        Car car1 = new Car("Ford", "Fiesta", 2023);
        System.out.println(Car.numberCar);
        Car car2 = new Car("Fiat", "Panda", 2020);
        System.out.println(Car.numberCar);

        System.out.println(car1.carDesc());
        System.out.println(car2.carDesc());

        Car.info(car1);
        Car.info(car2);

    }
}
