package final_static;

public class Car {

    public static final String SERIAL_NUMBER_CAR = "2wr5245";
    public static int numberCar = 0;
    private String company;
    private String model;
    private int productionYear;

    public Car(String company, String model, int productionYear) {
        this.company = company;
        this.model = model;
        this.productionYear = productionYear;
        Car.numberCar++;
        System.out.println("Numer car: " + Car.numberCar);
    }

    public String carDesc() {
        return company + " " + model + "/ " + Car.SERIAL_NUMBER_CAR;
    }

    public static void info(Car car) {
//        Car car = new Car("Opel", "Corsa", 2021);
        System.out.println(SERIAL_NUMBER_CAR + ", " + numberCar + ", " + car.carDesc());
    }
}
