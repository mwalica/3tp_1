package com.example.temp40124_3tp_1_lifecycle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.NumberPicker;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String COUNTER_KEY = "counter_key";
    private NumberPicker numberPicker;
    private TextView tvResult;
    private int counter = 50;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(savedInstanceState != null) {
            counter = savedInstanceState.getInt(COUNTER_KEY);
        }

        numberPicker = findViewById(R.id.numberPicker);
        tvResult = findViewById(R.id.tvResult);

        numberPicker.setMaxValue(100);
        numberPicker.setValue(counter);

        tvResult.setText(String.valueOf(counter));

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int oldValue, int newValue) {
                counter = newValue;
                tvResult.setText(String.valueOf(counter));
            }
        });


    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(COUNTER_KEY, counter);
    }
}