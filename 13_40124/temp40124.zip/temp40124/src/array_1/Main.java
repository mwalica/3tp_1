package array_1;

import java.util.Arrays;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        int[] nums = new int[20];
        boolean bools[] = new boolean[4];
        String[] cars = new String[3];

        for (int i = 0; i < nums.length; i++) {
            nums[i] = new Random().nextInt(101);
        }
        cars[1] = "BMW";
//        cars[4] = "Toyota";
        System.out.println(Arrays.toString(nums));
        System.out.println(Arrays.toString(bools));
        System.out.println(Arrays.toString(cars));

        System.out.println("=====");
        String[] names = {"Iza", "Kasia", "Adam"};
        System.out.println(Arrays.toString(names));
        String[] names3 = names.clone();
        String[] names2 = names;
        names2[1] = "Gustaw";
        String[] names4 = Arrays.copyOf(names, 12);
        String[] names5 = Arrays.copyOfRange(names, 0,2);
        System.out.println(Arrays.toString(names));
        System.out.println(Arrays.toString(names2));
        System.out.println(Arrays.toString(names3));
        System.out.println(Arrays.toString(names4));
        System.out.println(Arrays.toString(names5));

        for(String name : names) {
            System.out.println(name);
        }


    }
}
