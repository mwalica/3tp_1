package com.example.temp110124_number_picker_name_3tp2.model;

public class Person {
    private String name;
    private int color;

    public Person(String name, int color) {
        this.name = name;
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public int getColor() {
        return color;
    }
}
