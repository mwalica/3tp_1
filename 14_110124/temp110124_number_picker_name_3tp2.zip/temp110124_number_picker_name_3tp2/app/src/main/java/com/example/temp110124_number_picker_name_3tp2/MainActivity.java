package com.example.temp110124_number_picker_name_3tp2;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.NumberPicker;
import android.widget.TextView;

import com.example.temp110124_number_picker_name_3tp2.model.Person;

public class MainActivity extends AppCompatActivity {

    private NumberPicker numberPicker;
    private TextView tvResult;
    private int currentIndex = 1;
    private Person[] persons = {
            new Person("Jan", Color.RED),
            new Person("Gustaw", Color.GREEN),
            new Person("Adam", Color.YELLOW),
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numberPicker = findViewById(R.id.numberPicker);
        tvResult = findViewById(R.id.tvResult);

        String[] names = new String[persons.length];
        for(int i = 0; i < names.length; i++) {
            names[i] = persons[i].getName();
        }

        numberPicker.setMaxValue(names.length - 1);
        numberPicker.setDisplayedValues(names);
        numberPicker.setValue(1);
        tvResult.setText(persons[currentIndex].getName());
        tvResult.setTextColor(persons[currentIndex].getColor());

        numberPicker.setOnValueChangedListener(new NumberPicker.OnValueChangeListener() {
            @Override
            public void onValueChange(NumberPicker numberPicker, int i, int newVal) {
                currentIndex = newVal;
                tvResult.setText(persons[currentIndex].getName());
                tvResult.setTextColor(persons[currentIndex].getColor());
            }
        });
    }
}