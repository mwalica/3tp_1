package example1;

public class Rectangle extends Shape {
    private int a;
    private int b;

    public Rectangle(int a, int b) {
        super("prostokąt");
        this.a = a;
        this.b = b;
    }

    public Rectangle(int a, int b, String name) {
        super(name);
        this.a = a;
        this.b = b;
    }

    public Rectangle(int a) {
        super("kwadrat");
        this.a = a;
        this.b = a;
    }

    @Override
    public void info() {
        super.info();
        System.out.println("Jestem" + name + " o boku a: " + a + " i boku b: " + b);
    }

}
