package com.example.temp261023_3tp_1_1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private LinearLayout linearLayout;
    private TextView tvText1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayout = findViewById(R.id.linearLayout);
        tvText1 = findViewById(R.id.tvText1);

        setMyScreen();


    }

    private void setMyScreen() {
        linearLayout.setBackgroundColor(Color.YELLOW);
        linearLayout.setBackgroundColor(Color.rgb(255, 78, 234));
        linearLayout.setBackgroundColor(getColor(R.color.color_1));
        tvText1.setText("To jest nowy tekst");
    }
}