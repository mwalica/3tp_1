package com.example.temp290224_example;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.temp290224_example.model.User;

public class MainActivity extends AppCompatActivity {

    public static final String NAME_KEY = "name_value";
    public static final String AGE_KEY = "age_value";
    public static final String USER_KEY = "user_obj";
    private Button btnSend;
    private EditText etName, etAge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSend = findViewById(R.id.btnSend);
        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = etName.getText().toString().trim();
                String age = etAge.getText().toString().trim();

                if(!name.isEmpty() && !age.isEmpty()) {
                    Intent intent = new Intent(MainActivity.this, SecondActivity.class);
//                    intent.putExtra(NAME_KEY, name);
//                    intent.putExtra(AGE_KEY, Integer.parseInt(age));
                    intent.putExtra(USER_KEY, new User(name, Integer.parseInt(age)));
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Proszę wpisać imię i wiek", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }
}