package com.example.temp290224_example;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.temp290224_example.model.User;

public class SecondActivity extends AppCompatActivity {

    private Button btnBack;
    private TextView tvResult;
    private String name = "";
    private int age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);


        btnBack = findViewById(R.id.btnBack);
        tvResult = findViewById(R.id.tvResult);

//        if(getIntent().hasExtra(MainActivity.NAME_KEY) && getIntent().hasExtra(MainActivity.AGE_KEY)) {
//            name = getIntent().getStringExtra(MainActivity.NAME_KEY);
//            age = getIntent().getIntExtra(MainActivity.AGE_KEY, 0);
//            tvResult.setText(name + " " + age);
//        }

        if (getIntent().hasExtra(MainActivity.USER_KEY)) {
            User user = (User) getIntent().getSerializableExtra(MainActivity.USER_KEY);
            tvResult.setText(user.getName() + " " + user.getAge());
        }

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}