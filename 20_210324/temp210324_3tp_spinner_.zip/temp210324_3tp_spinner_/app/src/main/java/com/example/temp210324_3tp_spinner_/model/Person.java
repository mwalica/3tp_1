package com.example.temp210324_3tp_spinner_.model;

import androidx.annotation.NonNull;

public class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @NonNull
    @Override
    public String toString() {
        return name;
    }

    public String presentation() {
        return name + ", " + age + " lat";
    }
}
