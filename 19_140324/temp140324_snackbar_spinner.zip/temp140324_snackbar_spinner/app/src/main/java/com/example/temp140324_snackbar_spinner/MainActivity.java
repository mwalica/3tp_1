package com.example.temp140324_snackbar_spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnShowSnackbar = findViewById(R.id.btnShowSnackbar);

        btnShowSnackbar.setOnClickListener(view -> {
            Snackbar.make(view, "Chcesz przejść do następnej aktywności?", Snackbar.LENGTH_LONG)
                    .setBackgroundTint(Color.BLUE)
                    .setAction("Tak", v -> {
                        Intent intent = new Intent(MainActivity.this, SpinnerActivity.class);
                        startActivity(intent);
                    })
                    .setAnimationMode(Snackbar.ANIMATION_MODE_SLIDE)
                    .setAnchorView(btnShowSnackbar)
                    .show();

        });


    }
}