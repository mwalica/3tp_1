package com.example.temp140324_snackbar_spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;

public class SpinnerActivity extends AppCompatActivity {

    private String selectedColor = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner);

        Spinner spinner = findViewById(R.id.spinner);
        Button btnSave = findViewById(R.id.btnSave);
        View view1 = findViewById(R.id.view1);
        View view2 = findViewById(R.id.view2);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selectedColor =  (String) adapterView.getSelectedItem();
                view1.setBackgroundColor(Color.parseColor(selectedColor));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btnSave.setOnClickListener(view -> {
            view2.setBackgroundColor(Color.parseColor(selectedColor));
        });
    }
}